<?php
declare(strict_types=1);

return [
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'port' => getenv('DB_PORT') ?: '3306',
        'database' => getenv('DB_NAME') ?: 'hireswipe',
        'username' => getenv('DB_USER') ?: 'student',
        'password' => getenv('DB_PASSWORD') ?: 'student',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'env' => getenv('APP_ENV') ?: 'development',
        'debug' => filter_var(getenv('APP_DEBUG') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'session_name' => 'hireswipe_session',
        'reset_token_ttl_minutes' => 30,
        'otp_ttl_minutes' => 5,
        'max_otp_attempts' => 5,
        'upload_dir' => getenv('UPLOAD_DIR') ?: dirname(__DIR__) . '/private_uploads',
        'max_upload_bytes' => 5242880,
    ],
];

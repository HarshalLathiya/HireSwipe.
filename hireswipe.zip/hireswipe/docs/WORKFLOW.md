# Workflow and architecture

```mermaid
flowchart TD
 A[Landing page] --> B{Account exists?}
 B -- No --> C[Register]
 B -- Yes --> D[Email and password login or mobile OTP]
 C --> E[Session created]
 D --> E
 E --> F{Role assigned?}
 F -- No --> G[Choose Job Seeker or Employer]
 F -- Yes --> H{Profile complete?}
 G --> I[Job Seeker profile]
 G --> J[Employer and company profile]
 H -- No --> I
 H -- No --> J
 H -- Yes --> K[Dashboard]
 I --> L[Job seeker dashboard]
 J --> M[Employer dashboard]
 L --> N[Browse jobs and apply]
 M --> O[Create/manage jobs]
 O --> P[Review applications]
 N --> Q[Track application status]
```

## Important architecture decisions
- `users` stores shared identity and authentication details; passwords are hashes only.
- `user_roles` supports either one or both roles on one account.
- `job_seeker_profiles` and `employer_profiles` store role-specific data.
- `companies` is separate from `job_listings`, so one company can publish many vacancies.
- Industries and employment types use lookup/mapping tables rather than comma-separated columns.
- Resume and image files are stored outside the public web root; MySQL stores metadata and storage keys.
- Age should be calculated from date of birth when needed; collect date of birth only if necessary.
- The demo OTP uses a short numeric code. TTL and attempts reduce risk, but production should add provider delivery, request throttling, and preferably keyed HMAC for OTP verification values.

# API Reference

All API POST/PATCH requests use JSON except `/api/upload.php` (multipart form data). Fetch `GET /api/csrf.php` first and include `_csrf` in the request body. Session cookies authenticate users.

- `POST /api/register.php`: `full_name,email,mobile_number,password,confirm_password`
- `POST /api/login.php`: `email,password`
- `POST /api/logout.php`
- `POST /api/select-role.php`: `role` = `job_seeker` or `employer`
- `POST /api/job-seeker-profile.php`: personal details, salary fields, `industry_ids[]`, `employment_type_ids[]`
- `POST /api/employer-profile.php`: `company_name,location,industry_id,website_url,company_description,position_title,contact_name`
- `GET /api/jobs.php`: published jobs
- `GET /api/jobs.php?mine=1`: employer's own jobs and application counts
- `POST /api/jobs.php`: create job listing
- `PATCH /api/jobs.php`: `job_id,status`
- `POST /api/applications.php`: `job_listing_id` (job seeker)
- `GET /api/applications.php`: current user's applications and employer applications for owned jobs
- `PATCH /api/applications.php`: `application_id,status` (employer)
- `POST /api/forgot-password.php`: `email`
- `POST /api/reset-password.php`: `token,password,confirm_password`
- `POST /api/request-otp.php`: `mobile_number,purpose`
- `POST /api/verify-otp.php`: `mobile_number,otp,purpose`
- `POST /api/upload.php`: multipart fields `file,kind` where kind is `resume`, `profile_picture`, or `company_logo`
- `GET /api/csrf.php`: CSRF token

In development, OTP/reset values are returned for testing. In production, use SMS/email providers and never expose these values to the client.

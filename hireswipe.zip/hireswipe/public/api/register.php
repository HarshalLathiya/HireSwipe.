<?php
require_once __DIR__.'/../../src/bootstrap.php';require_method('POST');$d=request_json();require_csrf($d);
$name=trim((string)($d['full_name']??''));$email=normalize_email((string)($d['email']??''));$mobile=normalize_mobile(isset($d['mobile_number'])?(string)$d['mobile_number']:null);$pw=(string)($d['password']??'');$confirm=(string)($d['confirm_password']??'');
if(mb_strlen($name)<2||mb_strlen($name)>150)json_response(['error'=>'Name must be 2–150 characters.'],422);
if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['error'=>'Enter a valid email address.'],422);
if(strlen($pw)<8||strlen($pw)>4096)json_response(['error'=>'Password must be at least 8 characters.'],422);
if(!hash_equals($pw,$confirm))json_response(['error'=>'Passwords do not match.'],422);
if($mobile!==null&&!preg_match('/^\+?[0-9]{8,15}$/',$mobile))json_response(['error'=>'Enter a valid mobile number with country code.'],422);
try{$q=$pdo->prepare('INSERT INTO users(full_name,email,email_normalized,mobile_number,mobile_normalized,password_hash,account_status,onboarding_status,onboarding_step) VALUES(?,?,?,?,?,?,"active","not_started","role_selection")');$q->execute([$name,$email,$email,$mobile,$mobile,password_hash($pw,PASSWORD_DEFAULT)]);$id=(int)$pdo->lastInsertId();audit($pdo,$id,$email,'login_success');session_regenerate_id(true);$_SESSION['user_id']=$id;$_SESSION['csrf_token']=bin2hex(random_bytes(32));json_response(['message'=>'Account created successfully. Choose your account type to continue.','redirect'=>'/role.php'],201);}catch(PDOException $e){if($e->getCode()==='23000')json_response(['error'=>'An account with that email or mobile number already exists.'],409);error_log($e->getMessage());json_response(['error'=>'Unable to create account.'],500);}

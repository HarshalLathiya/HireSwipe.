async function hsApi(url, method='GET', payload=null) {
  const options={method,headers:{'Accept':'application/json'}};
  if(payload!==null){options.headers['Content-Type']='application/json';payload._csrf=payload._csrf||window.HS_CSRF;options.body=JSON.stringify(payload);}
  const response=await fetch(url,options);let data={};try{data=await response.json()}catch(e){}
  if(!response.ok)throw new Error(data.error||'Request failed');return data;
}
function hsMessage(text, ok=false){const el=document.querySelector('#page-message, #form-message');if(el){el.textContent=text;el.classList.toggle('success',ok);el.classList.toggle('error',!ok)}}
document.addEventListener('click',async ev=>{
 const logout=ev.target.closest('[data-logout]');if(logout){ev.preventDefault();try{await hsApi('/api/logout.php','POST',{});location.href='/';}catch(e){hsMessage(e.message)}}
});
document.addEventListener('submit',async ev=>{
 const form=ev.target.closest('[data-api-form]');if(!form)return;
 ev.preventDefault();const data={};for(const [key,value] of new FormData(form).entries()){if(Object.prototype.hasOwnProperty.call(data,key)){if(!Array.isArray(data[key]))data[key]=[data[key]];data[key].push(value);}else{data[key]=value;}}const endpoint=form.dataset.endpoint;const method=form.dataset.method||'POST';
 try{const out=await hsApi(endpoint,method,data);let msg=out.message||'Saved successfully.';if(out.development_token){msg+=' Development reset token: '+out.development_token+' — open /reset-password.php?token='+out.development_token;}if(out.development_otp)msg+=' Development OTP: '+out.development_otp;hsMessage(msg,true);if(out.redirect)setTimeout(()=>location.href=out.redirect,350);else if(out.next_step){const routes={role_selection:'/role.php',job_seeker_profile:'/job-seeker-profile.php',employer_profile:'/employer-profile.php',dashboard:'/dashboard.php'};if(routes[out.next_step])setTimeout(()=>location.href=routes[out.next_step],500);}}
 catch(err){hsMessage(err.message,false)}
});
document.querySelectorAll('[data-role-choice]').forEach(btn=>btn.addEventListener('click',async()=>{try{const r=await hsApi('/api/select-role.php','POST',{role:btn.dataset.roleChoice});location.href=r.redirect;}catch(e){hsMessage(e.message)}}));
document.querySelectorAll('[data-apply-job]').forEach(btn=>btn.addEventListener('click',async()=>{try{const r=await hsApi('/api/applications.php','POST',{job_listing_id:btn.dataset.applyJob});hsMessage(r.message,true);btn.disabled=true;btn.textContent='Applied';}catch(e){hsMessage(e.message)}}));
document.querySelectorAll('[data-status-application]').forEach(sel=>sel.addEventListener('change',async()=>{try{await hsApi('/api/applications.php','PATCH',{application_id:sel.dataset.statusApplication,status:sel.value});hsMessage('Application status updated.',true)}catch(e){hsMessage(e.message)}}));
document.querySelectorAll('[data-job-status]').forEach(sel=>sel.addEventListener('change',async()=>{try{await hsApi('/api/jobs.php','PATCH',{job_id:sel.dataset.jobStatus,status:sel.value});hsMessage('Job status updated.',true)}catch(e){hsMessage(e.message)}}));
document.querySelectorAll('[data-password-match]').forEach(form=>form.addEventListener('submit',ev=>{const p=form.querySelector('[name=password]'),c=form.querySelector('[name=confirm_password]');if(p&&c&&p.value!==c.value){ev.preventDefault();hsMessage('Passwords do not match.');}}));

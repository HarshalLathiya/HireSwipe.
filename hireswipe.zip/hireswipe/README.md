# HireSwipe — Full PHP + MySQL Application Starter

A complete local-development starter for a two-sided job platform: job seekers can register, complete a profile, manage resumes, browse jobs and apply; employers can register, create a company profile, publish/manage job listings and review applications.

## Stack
- PHP 8.1+
- MySQL 8.0+
- PDO with prepared statements
- HTML, CSS, vanilla JavaScript
- PHP sessions, password hashing, CSRF protection

## Features implemented
- Responsive landing page
- Registration and email/password sign-in
- Mobile OTP challenge workflow (development OTP is shown locally; production SMS provider integration required)
- Forgot password and reset password (development reset token is shown locally; production email provider integration required)
- Role selection for job seeker or employer
- Resumable onboarding status
- Job seeker profile, education, experience, employment preferences and industry preferences
- Private resume/profile-picture upload endpoint with basic file validation
- Employer profile and company information
- Create, publish, edit/status-change and list job postings
- Job seeker job search/listing and application submission
- Employer application review/status updates
- Dashboards for both user types
- MySQL schema, seed lookup data, workflow/API docs

## Quick start
1. Install PHP 8.1+ with extensions `pdo_mysql`, `fileinfo`, and `mbstring`; install MySQL 8.0+.
2. Import `database/schema.sql` in phpMyAdmin or run:
   ```bash
   mysql -u root -p < database/schema.sql
   ```
3. Copy `config/config.example.php` to `config/config.php`, then update DB credentials.
4. Set a private upload directory outside `public/` in `config/config.php`.
5. From the project directory run:
   ```bash
   php -S 127.0.0.1:8000 -t public
   ```
6. Visit `http://127.0.0.1:8000`.

### If using XAMPP
The safest setup is to configure Apache DocumentRoot to the project's `public/` directory, or copy the contents of `public/` into your web root while keeping `src/`, `config/`, and `private_uploads/` outside the public web root. Do not open PHP files by double-clicking them. They must be served by PHP/Apache. The CSS is at `public/assets/styles.css`.

## Demo flow
1. Register an account.
2. Sign in.
3. Select Job Seeker or Employer.
4. Complete that profile.
5. Job seekers can browse/apply to published jobs.
6. Employers can create/publish jobs and review applications.

For local testing, the OTP and password reset token are returned by the API only when `APP_ENV=development`. No real SMS or email is sent unless you integrate a provider.

## Security / production checklist
This is a substantial starter application, but it is not a substitute for a security review. Before production:
- Configure HTTPS and secure cookies.
- Set `APP_ENV=production` and `APP_DEBUG=false`.
- Integrate a real SMS provider and email provider; never return OTP/reset tokens in production.
- Configure a private upload path outside the web root and add malware scanning, strict authorization, file retention, and safe download handling.
- Add infrastructure-backed rate limiting for login, OTP, and password reset endpoints.
- Add email verification delivery and account activation policy.
- Configure backups, migrations, logging/monitoring, and least-privilege DB credentials.
- Review privacy, consent, retention, and local legal requirements.
- Test with a staging database before production use.

## Routes
Public pages: `/`, `/register.php`, `/login.php`, `/forgot-password.php`, `/reset-password.php`, `/jobs.php`
Authenticated pages: `/role.php`, `/job-seeker-profile.php`, `/employer-profile.php`, `/job-seeker-dashboard.php`, `/employer-dashboard.php`, `/job.php`, `/applications.php`
JSON API endpoints are documented in `docs/API.md`.

Confirm password is validated only and is never stored. Age is represented by date of birth where collected. Resume and image file contents are stored in private storage; only file metadata/storage keys are in MySQL.

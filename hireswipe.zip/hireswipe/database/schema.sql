CREATE DATABASE IF NOT EXISTS hireswipe CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hireswipe;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS application_status_history;
DROP TABLE IF EXISTS job_applications;
DROP TABLE IF EXISTS login_audit_logs;
DROP TABLE IF EXISTS user_sessions;
DROP TABLE IF EXISTS password_reset_tokens;
DROP TABLE IF EXISTS otp_challenges;
DROP TABLE IF EXISTS email_verification_tokens;
DROP TABLE IF EXISTS job_listing_industries;
DROP TABLE IF EXISTS job_listing_employment_types;
DROP TABLE IF EXISTS job_listings;
DROP TABLE IF EXISTS resumes;
DROP TABLE IF EXISTS job_seeker_industries;
DROP TABLE IF EXISTS job_seeker_employment_types;
DROP TABLE IF EXISTS work_experiences;
DROP TABLE IF EXISTS education_records;
DROP TABLE IF EXISTS employer_profiles;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS job_seeker_profiles;
DROP TABLE IF EXISTS user_roles;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS employment_types;
DROP TABLE IF EXISTS industries;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(254) NOT NULL,
 email_normalized VARCHAR(254) NOT NULL UNIQUE,
 mobile_number VARCHAR(25) NULL,
 mobile_normalized VARCHAR(25) NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 email_verified_at DATETIME NULL,
 mobile_verified_at DATETIME NULL,
 account_status ENUM('pending_verification','active','suspended','deleted') NOT NULL DEFAULT 'active',
 onboarding_status ENUM('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
 onboarding_step VARCHAR(80) NULL,
 last_login_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 deleted_at DATETIME NULL,
 KEY idx_users_status(account_status),
 KEY idx_users_onboarding(onboarding_status)
) ENGINE=InnoDB;

CREATE TABLE roles (
 id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 role_key VARCHAR(40) NOT NULL UNIQUE,
 display_name VARCHAR(80) NOT NULL
) ENGINE=InnoDB;
INSERT INTO roles(role_key,display_name) VALUES ('job_seeker','Job Seeker'),('employer','Employer');

CREATE TABLE user_roles (
 user_id BIGINT UNSIGNED NOT NULL,
 role_id TINYINT UNSIGNED NOT NULL,
 assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,role_id),
 CONSTRAINT fk_ur_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_ur_role FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE industries (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL UNIQUE,
 slug VARCHAR(140) NOT NULL UNIQUE,
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
INSERT INTO industries(name,slug) VALUES
('Information Technology','information-technology'),('Healthcare','healthcare'),('Finance','finance'),
('Education','education'),('Manufacturing','manufacturing'),('Retail','retail'),('Hospitality','hospitality'),
('Agriculture','agriculture'),('Design','design'),('Other','other');

CREATE TABLE employment_types (
 id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 type_key VARCHAR(40) NOT NULL UNIQUE,
 display_name VARCHAR(80) NOT NULL
) ENGINE=InnoDB;
INSERT INTO employment_types(type_key,display_name) VALUES
('full_time','Full-time'),('part_time','Part-time'),('contract','Contract'),
('internship','Internship'),('freelance','Freelance'),('temporary','Temporary');

CREATE TABLE job_seeker_profiles (
 user_id BIGINT UNSIGNED PRIMARY KEY,
 date_of_birth DATE NULL,
 location VARCHAR(180) NULL,
 nationality VARCHAR(100) NULL,
 highest_qualification VARCHAR(150) NULL,
 total_experience_months SMALLINT UNSIGNED NULL,
 expected_salary_min DECIMAL(12,2) NULL,
 expected_salary_max DECIMAL(12,2) NULL,
 salary_currency CHAR(3) NOT NULL DEFAULT 'INR',
 profile_picture_key VARCHAR(500) NULL,
 headline VARCHAR(180) NULL,
 summary TEXT NULL,
 profile_completed_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_jsp_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT chk_jsp_salary CHECK(expected_salary_min IS NULL OR expected_salary_max IS NULL OR expected_salary_max>=expected_salary_min)
) ENGINE=InnoDB;

CREATE TABLE education_records (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 qualification VARCHAR(150) NOT NULL,
 institution_name VARCHAR(180) NULL,
 field_of_study VARCHAR(150) NULL,
 graduation_year YEAR NULL,
 grade_or_score VARCHAR(50) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_education_user(user_id),
 CONSTRAINT fk_education_user FOREIGN KEY(user_id) REFERENCES job_seeker_profiles(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE work_experiences (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 job_title VARCHAR(150) NOT NULL,
 company_name VARCHAR(180) NULL,
 location VARCHAR(180) NULL,
 employment_type_id TINYINT UNSIGNED NULL,
 start_date DATE NULL,
 end_date DATE NULL,
 is_current TINYINT(1) NOT NULL DEFAULT 0,
 description TEXT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_experience_user(user_id),
 CONSTRAINT fk_experience_user FOREIGN KEY(user_id) REFERENCES job_seeker_profiles(user_id) ON DELETE CASCADE,
 CONSTRAINT fk_experience_type FOREIGN KEY(employment_type_id) REFERENCES employment_types(id) ON DELETE SET NULL,
 CONSTRAINT chk_experience_dates CHECK(end_date IS NULL OR start_date IS NULL OR end_date>=start_date)
) ENGINE=InnoDB;

CREATE TABLE job_seeker_industries (
 user_id BIGINT UNSIGNED NOT NULL,
 industry_id INT UNSIGNED NOT NULL,
 PRIMARY KEY(user_id,industry_id),
 CONSTRAINT fk_jsi_user FOREIGN KEY(user_id) REFERENCES job_seeker_profiles(user_id) ON DELETE CASCADE,
 CONSTRAINT fk_jsi_industry FOREIGN KEY(industry_id) REFERENCES industries(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE job_seeker_employment_types (
 user_id BIGINT UNSIGNED NOT NULL,
 employment_type_id TINYINT UNSIGNED NOT NULL,
 PRIMARY KEY(user_id,employment_type_id),
 CONSTRAINT fk_jset_user FOREIGN KEY(user_id) REFERENCES job_seeker_profiles(user_id) ON DELETE CASCADE,
 CONSTRAINT fk_jset_type FOREIGN KEY(employment_type_id) REFERENCES employment_types(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE resumes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 original_filename VARCHAR(255) NOT NULL,
 storage_key VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 file_size_bytes BIGINT UNSIGNED NOT NULL,
 is_primary TINYINT(1) NOT NULL DEFAULT 0,
 uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 deleted_at DATETIME NULL,
 KEY idx_resumes_user(user_id),
 CONSTRAINT fk_resumes_user FOREIGN KEY(user_id) REFERENCES job_seeker_profiles(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE companies (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 company_name VARCHAR(180) NOT NULL,
 location VARCHAR(180) NULL,
 industry_id INT UNSIGNED NULL,
 website_url VARCHAR(255) NULL,
 company_description TEXT NULL,
 logo_storage_key VARCHAR(500) NULL,
 verification_status ENUM('unverified','pending','verified','rejected') NOT NULL DEFAULT 'unverified',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 deleted_at DATETIME NULL,
 KEY idx_company_industry(industry_id),
 KEY idx_company_name(company_name),
 CONSTRAINT fk_company_industry FOREIGN KEY(industry_id) REFERENCES industries(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE employer_profiles (
 user_id BIGINT UNSIGNED PRIMARY KEY,
 company_id BIGINT UNSIGNED NULL,
 position_title VARCHAR(150) NULL,
 contact_name VARCHAR(150) NULL,
 is_company_admin TINYINT(1) NOT NULL DEFAULT 1,
 profile_completed_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_employer_company(company_id),
 CONSTRAINT fk_ep_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_ep_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE job_listings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 company_id BIGINT UNSIGNED NOT NULL,
 created_by_user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(180) NOT NULL,
 description MEDIUMTEXT NOT NULL,
 location VARCHAR(180) NULL,
 industry_id INT UNSIGNED NULL,
 employment_type_id TINYINT UNSIGNED NULL,
 salary_min DECIMAL(12,2) NULL,
 salary_max DECIMAL(12,2) NULL,
 salary_currency CHAR(3) NOT NULL DEFAULT 'INR',
 salary_period ENUM('hour','day','month','year','not_disclosed') NOT NULL DEFAULT 'not_disclosed',
 minimum_experience_months SMALLINT UNSIGNED NULL,
 qualifications TEXT NULL,
 status ENUM('draft','published','closed','archived') NOT NULL DEFAULT 'draft',
 application_deadline DATE NULL,
 published_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 deleted_at DATETIME NULL,
 KEY idx_jobs_company_status(company_id,status),
 KEY idx_jobs_status_published(status,published_at),
 KEY idx_jobs_industry(industry_id),
 CONSTRAINT fk_job_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE RESTRICT,
 CONSTRAINT fk_job_creator FOREIGN KEY(created_by_user_id) REFERENCES users(id) ON DELETE RESTRICT,
 CONSTRAINT fk_job_industry FOREIGN KEY(industry_id) REFERENCES industries(id) ON DELETE SET NULL,
 CONSTRAINT fk_job_type FOREIGN KEY(employment_type_id) REFERENCES employment_types(id) ON DELETE SET NULL,
 CONSTRAINT chk_job_salary CHECK(salary_min IS NULL OR salary_max IS NULL OR salary_max>=salary_min)
) ENGINE=InnoDB;

CREATE TABLE job_listing_industries (
 job_listing_id BIGINT UNSIGNED NOT NULL,
 industry_id INT UNSIGNED NOT NULL,
 PRIMARY KEY(job_listing_id,industry_id),
 CONSTRAINT fk_jli_job FOREIGN KEY(job_listing_id) REFERENCES job_listings(id) ON DELETE CASCADE,
 CONSTRAINT fk_jli_industry FOREIGN KEY(industry_id) REFERENCES industries(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE job_listing_employment_types (
 job_listing_id BIGINT UNSIGNED NOT NULL,
 employment_type_id TINYINT UNSIGNED NOT NULL,
 PRIMARY KEY(job_listing_id,employment_type_id),
 CONSTRAINT fk_jlet_job FOREIGN KEY(job_listing_id) REFERENCES job_listings(id) ON DELETE CASCADE,
 CONSTRAINT fk_jlet_type FOREIGN KEY(employment_type_id) REFERENCES employment_types(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE job_applications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_listing_id BIGINT UNSIGNED NOT NULL,
 applicant_user_id BIGINT UNSIGNED NOT NULL,
 resume_id BIGINT UNSIGNED NULL,
 cover_letter TEXT NULL,
 status ENUM('submitted','viewed','shortlisted','rejected','withdrawn','hired') NOT NULL DEFAULT 'submitted',
 applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_application_job_user(job_listing_id,applicant_user_id),
 KEY idx_application_applicant(applicant_user_id,applied_at),
 KEY idx_application_job_status(job_listing_id,status),
 CONSTRAINT fk_application_job FOREIGN KEY(job_listing_id) REFERENCES job_listings(id) ON DELETE CASCADE,
 CONSTRAINT fk_application_user FOREIGN KEY(applicant_user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_application_resume FOREIGN KEY(resume_id) REFERENCES resumes(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE application_status_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 application_id BIGINT UNSIGNED NOT NULL,
 changed_by_user_id BIGINT UNSIGNED NULL,
 old_status VARCHAR(30) NULL,
 new_status VARCHAR(30) NOT NULL,
 note VARCHAR(500) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_app_history(application_id,created_at),
 CONSTRAINT fk_ash_application FOREIGN KEY(application_id) REFERENCES job_applications(id) ON DELETE CASCADE,
 CONSTRAINT fk_ash_user FOREIGN KEY(changed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE email_verification_tokens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_email_token_user(user_id,expires_at),
 CONSTRAINT fk_evt_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE otp_challenges (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 mobile_normalized VARCHAR(25) NOT NULL,
 purpose ENUM('login','verify_mobile','password_reset') NOT NULL,
 otp_hash CHAR(64) NOT NULL,
 expires_at DATETIME NOT NULL,
 verified_at DATETIME NULL,
 consumed_at DATETIME NULL,
 attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 max_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 5,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_otp_mobile_purpose(mobile_normalized,purpose,expires_at),
 KEY idx_otp_user(user_id,created_at),
 CONSTRAINT fk_otp_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE password_reset_tokens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 request_ip VARCHAR(45) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_reset_user(user_id,expires_at),
 CONSTRAINT fk_reset_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user_sessions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 session_token_hash CHAR(64) NOT NULL UNIQUE,
 user_agent VARCHAR(500) NULL,
 ip_address VARCHAR(45) NULL,
 expires_at DATETIME NOT NULL,
 revoked_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_sessions_user(user_id,expires_at),
 CONSTRAINT fk_sessions_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE login_audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 identifier_submitted VARCHAR(254) NULL,
 event_type ENUM('login_success','login_failure','logout','otp_requested','otp_failure','password_reset_requested','password_reset_success','application_submitted','application_status_changed') NOT NULL,
 ip_address VARCHAR(45) NULL,
 user_agent VARCHAR(500) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_audit_user_time(user_id,created_at),
 KEY idx_audit_event_time(event_type,created_at),
 CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

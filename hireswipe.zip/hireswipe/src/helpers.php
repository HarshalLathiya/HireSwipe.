<?php
declare(strict_types=1);
function e(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function json_response(array $d,int $s=200): never { http_response_code($s); header('Content-Type: application/json; charset=utf-8'); echo json_encode($d,JSON_UNESCAPED_SLASHES); exit; }
function request_json(): array { $d=json_decode(file_get_contents('php://input')?:'',true); return is_array($d)?$d:[]; }
function require_method(string $m): void { if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!==strtoupper($m)) json_response(['error'=>'Method not allowed'],405); }
function csrf_token(): string { if(empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32)); return $_SESSION['csrf_token']; }
function require_csrf(array $d): void { $v=$d['_csrf']??($_SERVER['HTTP_X_CSRF_TOKEN']??''); if(!is_string($v)||empty($_SESSION['csrf_token'])||!hash_equals($_SESSION['csrf_token'],$v)) json_response(['error'=>'Invalid CSRF token. Refresh and retry.'],419); }
function current_user_id(): ?int { return isset($_SESSION['user_id'])?(int)$_SESSION['user_id']:null; }
function require_auth(): int { $id=current_user_id(); if(!$id) json_response(['error'=>'Please sign in first.'],401); return $id; }
function normalize_email(string $s): string { return mb_strtolower(trim($s),'UTF-8'); }
function normalize_mobile(?string $s): ?string { if($s===null||trim($s)==='')return null; return preg_replace('/[\s().-]+/','',trim($s)); }
function audit(PDO $pdo,?int $uid,?string $ident,string $event): void { try{$q=$pdo->prepare('INSERT INTO login_audit_logs(user_id,identifier_submitted,event_type,ip_address,user_agent) VALUES(?,?,?,?,?)');$q->execute([$uid,$ident,$event,$_SERVER['REMOTE_ADDR']??null,substr($_SERVER['HTTP_USER_AGENT']??'',0,500)]);}catch(Throwable $e){error_log($e->getMessage());} }
function require_role(PDO $pdo,int $uid,string $role): void { $q=$pdo->prepare('SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.role_key=?');$q->execute([$uid,$role]);if(!$q->fetchColumn())json_response(['error'=>'You do not have permission for this action.'],403); }
function page_start(string $title,string $active=''): void { $uid=current_user_id(); ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> · HireSwipe</title><link rel="stylesheet" href="assets/styles.css"></head><body><header class="topbar"><a class="brand" href="/">HireSwipe<span>.</span></a><nav><a href="/jobs.php">Find jobs</a><?php if($uid):?><a href="/role.php">My account</a><a href="#" data-logout>Log out</a><?php else:?><a href="/login.php">Sign in</a><a class="nav-cta" href="/register.php">Get started</a><?php endif;?></nav></header><main class="page-wrap"><?php }
function page_end(): void { ?><footer><a class="brand" href="/">HireSwipe<span>.</span></a><span>Connecting ambition with opportunity.</span><span>© <?=date('Y')?> HireSwipe</span></footer><script src="assets/app.js"></script></body></html><?php }
function page_message(): void { ?><p class="notice" id="page-message" role="status"></p><?php }
function get_csrf_for_page(): string { return csrf_token(); }

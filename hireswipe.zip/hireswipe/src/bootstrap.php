<?php
declare(strict_types=1);
$configFile = __DIR__ . '/../config/config.php';
if (!is_file($configFile)) { http_response_code(500); exit('Missing config/config.php. Copy config/config.example.php first.'); }
$config = require $configFile;
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_name($config['app']['session_name'] ?? 'hireswipe_session');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$isHttps,'httponly'=>true,'samesite'=>'Lax']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/helpers.php';
try {
 $d=$config['db']; $dsn="mysql:host={$d['host']};port={$d['port']};dbname={$d['database']};charset={$d['charset']}";
 $pdo=new PDO($dsn,$d['username'],$d['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
} catch(Throwable $e) { error_log('HireSwipe DB: '.$e->getMessage()); http_response_code(500); exit('Database connection failed. Check config/config.php.'); }
